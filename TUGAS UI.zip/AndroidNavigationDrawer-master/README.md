# AndroidNavigationDrawer
Simple Navigation Drawer using Navigation View Android Material Design

![alt tag](https://3.bp.blogspot.com/-saOvzbdBY4w/VtmyXkrXGsI/AAAAAAAABSk/X4ThuFSb2Hg/s600/Screenshot_2016-03-04-22-48-28.png "Simple Navigation Drawer")
